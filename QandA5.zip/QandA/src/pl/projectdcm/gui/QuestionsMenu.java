package pl.projectdcm.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

import pl.projectdcm.data.DBManager;
import pl.projectdcm.data.ResultSetTableModel;

public class QuestionsMenu extends JFrame {

	private static final long serialVersionUID = -6846315193410091203L;
/*
	public static void main(String[] args) {
		JFrame app_frame = new QuestionsMenu(0);
		app_frame.setVisible(true);
	}*/

	private JTextArea _editor;
	private JButton _sendButton;
	private JTable _table;
	private ResultSetTableModel _tableModel;
	private JButton AddQuestion;
	private JButton ShowAllQuestion;
	private JButton ShowAnswers;
	private JButton AddButt;
	private int idUser;

	public QuestionsMenu(int id) {
		super("Questions and Answers");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1000, 500);
		setLocationRelativeTo(null);
		initGUI();
		sendQuery("select * from pytania");
		idUser = id;
	}

	private void initGUI() {
		// getContentPane().setLayout(new GridLayout(6, 2));
		getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		// query area
		_editor = new JTextArea("");
		_editor.setFont(new Font("Courier New", 0, 16));
		_editor.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		JScrollPane editorScroll = new JScrollPane();
		editorScroll.setViewportView(_editor);
		editorScroll.setPreferredSize(new Dimension(1000, 50));
		c.fill = GridBagConstraints.BOTH;
		c.ipady = 50;
		c.ipadx = 750;
		c.gridx = 0;
		c.gridwidth = 1;
		c.gridy = 0;
		c.anchor = GridBagConstraints.NORTH;
		add(editorScroll, c);

		// data table
		_tableModel = new ResultSetTableModel(null);
		_table = new JTable(_tableModel);

		JScrollPane tableScroll = new JScrollPane(_table);
		tableScroll.setPreferredSize(new Dimension(1000, 200));
		c.ipady = 250;
		c.ipadx = 1000;
		c.weighty = 0.1;
		c.gridwidth = 2;
		c.gridy = 1;
		add(tableScroll, c);

		// button

		AddQuestion = new JButton("Dodaj Pytanie");
		c.ipadx = 25;
		c.ipady = 50;
		c.gridwidth = 2;
		c.gridx = 1;
		c.gridy = 0;
		c.anchor = GridBagConstraints.NORTH;
		AddQuestion.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == AddQuestion) {
					int max = maxAID() + 1;
					if (_editor.getText().isEmpty()) {
					} else {
						
						String query = "INSERT INTO pytania ( id , pytanie , iddodajacego )VALUES ( "
								+ max
								+ " , '"
								+ _editor.getText()
								+ "', "
								+ idUser + " ) ;";
						sendQuery(query);
					}

					String query2 = "select * from pytania";
					sendQuery(query2);

				}
			}
		});
		add(AddQuestion, c);

		AddButt = new JButton("Send Query");
		c.ipadx = 25;
		c.ipady = 50;
		c.weightx = 0.1;
		c.gridwidth = 1;
		c.gridx = 0;
		c.gridy = 2;
		c.anchor = GridBagConstraints.LINE_START;
		AddButt.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				sendQuery(_editor.getText());
			}
		});
		add(AddButt, c);

		_sendButton = new JButton("Usun pytanie");
		_sendButton.setForeground(Color.RED);
		c.gridx = 1;
		c.gridy = 2;

		_sendButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == _sendButton) {
					int row = _table.getSelectedRow();
					if (row >= 0) {
						int idQuestion = (Integer) _table.getValueAt(row, 0);
						if (canI()) {
							sendQuery("DELETE FROM pytania WHERE id = "
									+ idQuestion);
							sendQuery("select * from pytania");
						}

					}
				}
			}
		});
		add(_sendButton, c);

		ShowAllQuestion = new JButton("Odswiez liste pytan");
		c.gridx = 1;
		c.gridy = 3;
		ShowAllQuestion.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == ShowAllQuestion) {
					sendQuery("select * from pytania");
				}
			}
		});

		add(ShowAllQuestion, c);

		ShowAnswers = new JButton("Pokaz Odpowiedz");
		c.gridx = 0;
		c.gridy = 3;
		ShowAnswers.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == ShowAnswers) {
					int row = _table.getSelectedRow();
					if (row >= 0) {
						int idQuestion = (Integer) _table.getValueAt(row, 0);
						showAnswers(idQuestion);
					}

				}
			}
		});
		add(ShowAnswers, c);

	}

	void showAnswers(int idQuestion) {
		JFrame app_frame2 = new Answers(idQuestion);
		app_frame2.setVisible(true);

	}

	int maxAID() {
		int id = 0;
		try {
			Statement stmt = DBManager.getConnection().createStatement();
			ResultSet queryResult = stmt
					.executeQuery("select id from pytania where id = (select max(id) from pytania);");
			queryResult.next();
			id = queryResult.getInt("id");
			queryResult.close();
			stmt.close();
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
		return id;
	}

	boolean canI() {
		boolean can = false;
		if (idUser == owner()) {

			can = true;
		}

		return can;
	}

	int owner() {
		int id = 0;
		try {
			Statement stmt = DBManager.getConnection().createStatement();
			int row = _table.getSelectedRow();
			if (row >= 0) {
				int idQuestion = (Integer) _table.getValueAt(row, 0);
				ResultSet queryResult = stmt
						.executeQuery("select iddodajacego from pytania where id = "
								+ idQuestion + ";");
				queryResult.next();
				id = queryResult.getInt("iddodajacego");
				queryResult.close();
				stmt.close();
			}
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
		return id;
	}
	
	protected void sendQuery(String query) {
		try {
			// read query from the editor
			// String query = _editor.getText();

			if (query.length() > 6
					&& (query.substring(0, 6).equalsIgnoreCase("insert")
							|| query.substring(0, 6).equalsIgnoreCase("update") || query
							.substring(0, 6).equalsIgnoreCase("delete"))) {
				Statement stmt = DBManager.getConnection().createStatement();
				stmt.executeUpdate(query);
				_tableModel.setResultSet(null);
				stmt.close();
			} else if ((query.length() > 6)
					&& (query.substring(0, 6).equalsIgnoreCase("select"))) {
				// create SQL statement and execute query read from the _editor
				Statement stmt = DBManager.getConnection().createStatement();
				ResultSet queryResult = stmt.executeQuery(query);
				// pass the resultSet to the table model (use setResultSet
				// method from the model)

				_tableModel.setResultSet(queryResult);

				// close the resultSet and statement
				queryResult.close();
				stmt.close();
			} else {
				Statement stmt = DBManager.getConnection().createStatement();
				stmt.execute(query);
				stmt.close();
			}
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
	}
}