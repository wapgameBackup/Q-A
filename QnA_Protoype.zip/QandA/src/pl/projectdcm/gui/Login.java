package pl.projectdcm.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import pl.projectdcm.data.DBManager;

public class Login extends JFrame {

	public static void main(String[] args) {
		JFrame app_frame = new Login();
		// JFrame app_frame = new QuestionsMenu();
		Staff staff = new Staff();
		staff.addSampleEntries();

		app_frame.setVisible(true);
	}

	private static final long serialVersionUID = -6846315193410091203L;

	private JTextArea _editor;
	private JButton CheckButton;
	boolean loginPodany = false;
	String login;
	String pass;
	int idUser;
	JTextField tytul;
	

	public Login() {
		super("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(400, 200);
		setLocationRelativeTo(null);
		initGUI();
	}

	private void initGUI() {
		getContentPane().setLayout(new GridLayout(3, 1));

		
		tytul = new JTextField();
		tytul.setText("Wpisz ponizej Login i wcisnij OK.");
		tytul.setHorizontalAlignment(JTextField.CENTER);
		tytul.setEnabled(false);
		add(tytul);

		// query area
		_editor = new JTextArea("");
		_editor.setFont(new Font("Courier New", 0, 16));
		_editor.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		_editor.setText("admin");

		JScrollPane editorScroll = new JScrollPane();
		editorScroll.setViewportView(_editor);
		editorScroll.setPreferredSize(new Dimension(1, 100));
		add(editorScroll);

		CheckButton = new JButton("OK");
		CheckButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == CheckButton) {
					if (_editor.getText().isEmpty()) {
						tytul.setText("Pusty Login? Wpisz tu Login i wcisnij OK.");
						_editor.setText("");

					} else {
						if (loginPodany == false) {

							login = _editor.getText();
							pass = getPassword(login);
							tytul.setText("Wpisz ponizej haslo i wcisnij OK");
							_editor.setText("admin1");
							loginPodany = true;
						}

						else {
							if (_editor.getText().equals(pass)) {

								JFrame app_frame = new QuestionsMenu(getId(login));
								app_frame.setVisible(true);
								setVisible(false);
							} else {
								tytul.setText("Bledny Login lub haslo. Wpisz Login i wcisnij OK. ");
								_editor.setText("");
								loginPodany = false;
							}

						}
					}
				}
			}
		});

		add(CheckButton);

	}

	String getPassword(String loginU) {
		String password = "pusto";
		try {
			Statement stmt = DBManager.getConnection().createStatement();
			ResultSet queryResult = stmt.executeQuery("select password from users where login = '" + loginU + "' ;");

			queryResult.next();
			password = queryResult.getString("password");
			queryResult.close();
			stmt.close();
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
		return password;
	}

	int getId(String loginU) {
		idUser = 0;
		try {
			Statement stmt = DBManager.getConnection().createStatement();
			ResultSet queryResult = stmt.executeQuery("select id from users where login = '" + loginU + "' ;");
			queryResult.next();
			idUser = queryResult.getInt("id");
			queryResult.close();
			stmt.close();
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}

		return idUser;
	}

	protected void sendQuery(String query) {
		try {
			// read query from the editor

			if (query.length() > 6 && (query.substring(0, 6).equalsIgnoreCase("insert")
					|| query.substring(0, 6).equalsIgnoreCase("update")
					|| query.substring(0, 6).equalsIgnoreCase("delete"))) {
				Statement stmt = DBManager.getConnection().createStatement();
				stmt.executeUpdate(query);
				stmt.close();
			} else if ((query.length() > 6) && (query.substring(0, 6).equalsIgnoreCase("select"))) {
				// create SQL statement and execute query read from the _editor
				Statement stmt = DBManager.getConnection().createStatement();
				ResultSet queryResult = stmt.executeQuery(query);
				// pass the resultSet to the table model (use setResultSet
				// method from the model)

				// close the resultSet and statement
				queryResult.close();
				stmt.close();
			} else {
				Statement stmt = DBManager.getConnection().createStatement();
				stmt.execute(query);
				stmt.close();
			}
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
	}
}