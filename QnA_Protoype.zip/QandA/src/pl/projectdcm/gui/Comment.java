package pl.projectdcm.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

import pl.projectdcm.data.DBManager;
import pl.projectdcm.data.ResultSetTableModel;

public class Comment extends JFrame {

	private static final long serialVersionUID = -6846315193410091203L;

	private JTextArea _editor;
	private JTable _table;
	private ResultSetTableModel _tableModel;
	private JButton AddAnswer;
	private JButton RankUp;
	private JButton RankDown;
	private JButton deleteAns;
	private JButton refreshAns;
	private JButton exitButton;

	int idQuestion;
	int idAnswer;
	int idUser;

	public Comment(int idUser, int idQuestion, int idAnswer) {
		super("Comment");
		setSize(1000, 500);
		setLocationRelativeTo(null);

		this.idQuestion = idQuestion;
		this.idAnswer = idAnswer;
		this.idUser = idUser;
		initGUI();
		refreshComments();

	}

	private void initGUI() {
		getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		// query area
		_editor = new JTextArea("");
		_editor.setFont(new Font("Courier New", 0, 16));
		_editor.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		JScrollPane editorScroll = new JScrollPane();
		editorScroll.setViewportView(_editor);
		editorScroll.setPreferredSize(new Dimension(1000, 50));
		c.fill = GridBagConstraints.BOTH;
		c.ipady = 50;
		c.ipadx = 500;
		c.gridx = 0;
		c.gridwidth = 2;
		c.gridy = 0;
		c.anchor = GridBagConstraints.NORTH;
		add(editorScroll, c);

		// data table
		_tableModel = new ResultSetTableModel(null);
		_table = new JTable(_tableModel);
		JScrollPane tableScroll = new JScrollPane(_table);
		tableScroll.setPreferredSize(new Dimension(1000, 200));
		c.ipady = 250;
		c.ipadx = 1000;
		c.weighty = 0.1;
		c.gridwidth = 4;
		c.gridy = 1;
		add(tableScroll, c);

		AddAnswer = new JButton("Dodaj komentarz");
		c.ipadx = 25;
		c.ipady = 50;
		c.gridwidth = 1;
		c.gridx = 2;
		c.gridy = 0;
		c.anchor = GridBagConstraints.NORTH;
		AddAnswer.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == AddAnswer) {
					int max = maxComment() + 1;
					if (_editor.getText().isEmpty()) {
					} else {
						String query = "INSERT INTO comments ( id , comment , idUser , idQuestion, idAnswer ) VALUES ( "
								+ max + " , '" + _editor.getText() + "'," + idUser + " , " + idQuestion + "," + idAnswer
								+ "  ) ;";
						sendQuery(query);
					}

					refreshComments();
				}
			}
		});

		add(AddAnswer, c);

		deleteAns = new JButton("Usun komentarz");
		deleteAns.setForeground(Color.RED);
		c.gridx = 3;
		c.gridy = 0;

		deleteAns.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == deleteAns) {
					int row = _table.getSelectedRow();
					if (row >= 0) {
						int idComments = (Integer) _table.getValueAt(row, 0);
						String query = "DELETE FROM comments WHERE id = " + idComments;
						sendQuery(query);
						refreshComments();

					}
				}
			}
		});
		add(deleteAns, c);

		refreshAns = new JButton("Odswiez liste komentarzy");
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 2;
		c.anchor = GridBagConstraints.SOUTH;
		refreshAns.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == refreshAns) {
					refreshComments();
				}
			}
		});
		add(refreshAns, c);

		exitButton = new JButton("Powrot");
		c.gridx = 2;
		c.gridy = 2;
		exitButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				
			}
		});
		add(exitButton, c);
		
	}

	int giveRank(int id) {
		int rank = 0;
		try {
			Statement stmt = DBManager.getConnection().createStatement();
			ResultSet queryResult = stmt.executeQuery("select rank from odpowiedzi where id = " + id + ";");
			queryResult.next();
			rank = queryResult.getInt("rank");
			queryResult.close();
			stmt.close();
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
		return rank;
	}

	int maxComment() {
		int id = 0;
		try {
			Statement stmt = DBManager.getConnection().createStatement();
			ResultSet queryResult = stmt
					.executeQuery("select id from comments where id = (select max(id) from comments );");
			queryResult.next();
			id = queryResult.getInt("id");
			queryResult.close();
			stmt.close();
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
		return id;
	}

	void refreshAnswers() {

		sendQuery("select id, odpowiedz, rank from odpowiedzi where idp=" + idQuestion);

	}

	void refreshComments() {

		if (idQuestion != 0) {
			sendQuery("select id, comment from comments where idQuestion = " + idQuestion);
		} else {
			sendQuery("select id ,comment from comments where idAnswer = " + idAnswer);
		}

	}

	protected void sendQuery(String query) {
		try {
			// read query from the editor
			// String query = _editor.getText();

			if (query.length() > 6 && (query.substring(0, 6).equalsIgnoreCase("insert")
					|| query.substring(0, 6).equalsIgnoreCase("update")
					|| query.substring(0, 6).equalsIgnoreCase("delete"))) {
				Statement stmt = DBManager.getConnection().createStatement();
				stmt.executeUpdate(query);
				_tableModel.setResultSet(null);
				stmt.close();
			} else if ((query.length() > 6) && (query.substring(0, 6).equalsIgnoreCase("select"))) {
				// create SQL statement and execute query read from the _editor
				Statement stmt = DBManager.getConnection().createStatement();
				ResultSet queryResult = stmt.executeQuery(query);
				// pass the resultSet to the table model (use setResultSet
				// method from the model)

				_tableModel.setResultSet(queryResult);

				// close the resultSet and statement
				queryResult.close();
				stmt.close();
			} else {
				Statement stmt = DBManager.getConnection().createStatement();
				stmt.execute(query);
				stmt.close();
			}
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
	}
}
