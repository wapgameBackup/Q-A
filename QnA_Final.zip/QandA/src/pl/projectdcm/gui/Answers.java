package pl.projectdcm.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

import pl.projectdcm.data.DBManager;
import pl.projectdcm.data.ResultSetTableModel;

public class Answers extends JFrame {

	private static final long serialVersionUID = -6846315193410091203L;

	private JTextArea _editor;
	private JTable _table;
	private ResultSetTableModel _tableModel;
	private JButton AddAnswer;
	private JButton RankUp;
	private JButton RankDown;
	private JButton deleteAns;
	private JButton refreshAns;
	private JButton ShowComments;
	private JButton emptyButton;
	private JButton AddButt;
	private JButton exitButton;
	private JButton editButton;

	int idQuestion;
	int idUser;

	public Answers(int idUser, int idQuestion) {
		super("Answers");
		setSize(1000, 500);
		setLocationRelativeTo(null);
		this.idQuestion = idQuestion;
		this.idUser = idUser;
		initGUI();
		refreshAnswers();
	}

	private void initGUI() {
		getContentPane().setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		// query area
		_editor = new JTextArea("");
		_editor.setFont(new Font("Courier New", 0, 16));
		_editor.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		JScrollPane editorScroll = new JScrollPane();
		editorScroll.setViewportView(_editor);
		editorScroll.setPreferredSize(new Dimension(1000, 50));
		c.fill = GridBagConstraints.BOTH;
		c.ipady = 50;
		c.ipadx = 500;
		c.gridx = 0;
		c.gridwidth = 2;
		c.gridy = 0;
		c.anchor = GridBagConstraints.NORTH;
		add(editorScroll, c);

		// data table
		_tableModel = new ResultSetTableModel(null);
		_table = new JTable(_tableModel);
		JScrollPane tableScroll = new JScrollPane(_table);
		tableScroll.setPreferredSize(new Dimension(1000, 200));
		c.ipady = 250;
		c.ipadx = 1000;
		c.weighty = 0.1;
		c.gridwidth = 5;
		c.gridy = 1;
		add(tableScroll, c);

		AddAnswer = new JButton("Dodaj odpowiedz");
		c.ipadx = 25;
		c.ipady = 50;
		c.gridwidth = 1;
		c.gridx = 2;
		c.gridy = 0;
		c.anchor = GridBagConstraints.NORTH;
		AddAnswer.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == AddAnswer) {
					int max = maxAIO() + 1;
					if (_editor.getText().isEmpty()) {
					} else {
						String query = "INSERT INTO odpowiedzi ( id , odpowiedz , rank , idp ,idUser) VALUES ( " + max + " , '"
								+ _editor.getText() + "', 0 , " + idQuestion + ", " + idUser + "  ) ;";
						sendQuery(query);
					}

					refreshAnswers();
				}
			}
		});
		add(AddAnswer, c);
		
		editButton = new JButton("Edytuj odpowiedz");
		c.gridx = 3;
		c.gridy = 0;
		editButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == editButton) {
					if (_editor.getText().isEmpty()) {
					} else {
						int row = _table.getSelectedRow();
						if (row >= 0) {
							int idAnswer = (Integer) _table.getValueAt(row, 0);
							if (canI()) {
								String query = "UPDATE odpowiedzi SET odpowiedz = '" + _editor.getText() + "' WHERE id =" + idAnswer;
								sendQuery(query);
							}

							refreshAnswers();
						}
					}
				}
				
			}
		});
		add(editButton, c);
		
		deleteAns = new JButton("Usun odpowiedz");
		deleteAns.setForeground(Color.RED);
		c.gridx = 4;
		c.gridy = 0;
		
		deleteAns.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == deleteAns) {
					int row = _table.getSelectedRow();
					if (row >= 0) {
						if(canI()) {
						int idQuestion = (Integer) _table.getValueAt(row, 0);
						String query = "DELETE FROM odpowiedzi WHERE id = " + idQuestion;
						sendQuery(query);
						refreshAnswers();
						}
					}
				}
			}
		});
		add(deleteAns, c);
		
		emptyButton = new JButton("TODO");
		c.gridx = 0;
		c.gridy = 2;
		//add(emptyButton, c);

		RankUp = new JButton("Zwieksz rank");
		c.ipadx = 25;
		c.ipady = 50;
		c.weightx = 0.1;
		c.gridwidth = 1;
		c.gridx = 1;
		c.gridy = 2;
		c.anchor = GridBagConstraints.LINE_START;
		RankUp.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == RankUp) {
				Rank(1);
					}

				}
			
		});

		add(RankUp, c);

		RankDown = new JButton("Zmniejsz rank");
		c.gridx = 1;
		c.gridy = 3;
		RankDown.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == RankDown) {
						Rank(-1);
						
					
				}
			}
		});

		add(RankDown, c);


		refreshAns = new JButton("Odswiez liste odpowiedzi");
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = 3;
		refreshAns.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == refreshAns) {
					refreshAnswers();
				}
			}
		});
		add(refreshAns, c);
		
		AddButt = new JButton("Send Query");
		c.gridx = 0;
		c.gridy = 2;
		c.gridwidth = 1;
		AddButt.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				sendQuery(_editor.getText());
			}
		});
		add(AddButt, c);
		
		exitButton = new JButton("Powrot");
		c.gridx = 2;
		c.gridy = 3;
		c.gridwidth = 3;
		exitButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				
			}
		});
		add(exitButton, c);

		ShowComments = new JButton("Pokaz Komentarz");
		c.gridx = 0;
		c.gridy = 3;
		c.gridwidth = 1;
		ShowComments.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source == ShowComments) {
					int row = _table.getSelectedRow();
					if (row >= 0) {
						int idAnswer = (Integer) _table.getValueAt(row, 0);
						showComments(idUser, idAnswer);
					}

				}
			}
		});
		add(ShowComments, c);
	}
	void Rank(int rank) {
		int row = _table.getSelectedRow();
		if (row >= 0) {
			int idAnswer = (Integer) _table.getValueAt(row, 0);
			
			int temp = 0;
			try {
				Statement stmt = DBManager.getConnection().createStatement();
				ResultSet queryResult = stmt.executeQuery("select rank from ranks where idAnswer = " + idAnswer + " and idUser = "+ idUser+";");
				queryResult.next();
				temp = queryResult.getInt("rank");
				queryResult.close();
				stmt.close();
			} catch (Exception e) {
				_editor.setText(e.getMessage());
			}		
			
			
			if (temp == 1 || temp ==-1){
				sendQuery("UPDATE ranks set rank = "+ rank + " where idUser =" + idUser +" and idAnswer = "+idAnswer +" ;");
				refreshAnswers();
				_editor.setText("Twoj glos dla tego pytania zostal zaaktualizowany");
				
			} else {
			sendQuery("INSERT INTO ranks ( rank , idUser , idQuestion , idAnswer ) " + "VALUES ("+ rank +" ,"+ idUser +" , 0, " + idAnswer + " ) ;");
			refreshAnswers();
			_editor.setText("Twoj glos zostal dodany");
			}
		}
	}
	
	void refreshRanks() {
		int max = maxAIO();
		for (int i = 1; i <= max; i++) {
			int rank = 0;
			try {
				Statement stmt = DBManager.getConnection().createStatement();
				ResultSet queryResult = stmt.executeQuery("select rank from ranks where idAnswer =" + i);
				while (queryResult.next()) {
					rank = rank + queryResult.getInt("rank");
				}

				String query = "UPDATE odpowiedzi SET rank = " + rank + " WHERE id =" + i;
				sendQuery(query);
				queryResult.close();
				stmt.close();
			} catch (Exception e) {
				_editor.setText(e.getMessage());
			}
		}

	}

	int giveRank(int id) {
		int rank = 0;
		try {
			Statement stmt = DBManager.getConnection().createStatement();
			ResultSet queryResult = stmt.executeQuery("select rank from odpowiedzi where id = " + id + ";");
			queryResult.next();
			rank = queryResult.getInt("rank");
			queryResult.close();
			stmt.close();
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
		return rank;
	}
	
	void setAnswersCounts() {
		
		int max = maxAIO();
		for (int i = 1; i <= max; i++) {
			int liczbaOdp = 0;
			try {
				Statement stmt = DBManager.getConnection().createStatement();
				ResultSet queryResult = stmt.executeQuery("select id from comments where idAnswer =" + i);
				while (queryResult.next()) {
					liczbaOdp++;
				}

				String query = "UPDATE odpowiedzi SET howManyComments = " + liczbaOdp + " WHERE id =" + i;
				sendQuery(query);
				queryResult.close();
				stmt.close();
			} catch (Exception e) {
				_editor.setText(e.getMessage());
			}
		}

	}

	int maxAIO() {
		int id = 0;
		try {
			Statement stmt = DBManager.getConnection().createStatement();
			ResultSet queryResult = stmt
					.executeQuery("select id from odpowiedzi where id = (select max(id) from odpowiedzi );");
			queryResult.next();
			id = queryResult.getInt("id");
			queryResult.close();
			stmt.close();
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
		return id;
	}

	void refreshAnswers() {

		refreshRanks();
		setAnswersCounts();
		sendQuery("select id, odpowiedz, rank, howManyComments from odpowiedzi where idp=" + idQuestion);

	}

	void showComments(int idUser, int idAnswer) {
		JFrame app_frame2 = new Comment(idUser, 0, idAnswer);
		app_frame2.setVisible(true);

	}
	
	boolean canI() {
		boolean can = false;
		if (idUser == owner()) {

			can = true;
		}

		return can;
	}

	int owner() {
		int id = 0;
		try {
			Statement stmt = DBManager.getConnection().createStatement();
			int row = _table.getSelectedRow();
			if (row >= 0) {
				int idAnswer = (Integer) _table.getValueAt(row, 0);
				ResultSet queryResult = stmt
						.executeQuery("select idUser from odpowiedzi where id = " + idAnswer + ";");
				queryResult.next();
				id = queryResult.getInt("idUser");
				queryResult.close();
				stmt.close();
			}
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
		return id;
	}

	protected void sendQuery(String query) {
		try {
			// read query from the editor
			// String query = _editor.getText();

			if (query.length() > 6 && (query.substring(0, 6).equalsIgnoreCase("insert")
					|| query.substring(0, 6).equalsIgnoreCase("update")
					|| query.substring(0, 6).equalsIgnoreCase("delete"))) {
				Statement stmt = DBManager.getConnection().createStatement();
				stmt.executeUpdate(query);
				_tableModel.setResultSet(null);
				stmt.close();
			} else if ((query.length() > 6) && (query.substring(0, 6).equalsIgnoreCase("select"))) {
				// create SQL statement and execute query read from the _editor
				Statement stmt = DBManager.getConnection().createStatement();
				ResultSet queryResult = stmt.executeQuery(query);
				// pass the resultSet to the table model (use setResultSet
				// method from the model)

				_tableModel.setResultSet(queryResult);

				// close the resultSet and statement
				queryResult.close();
				stmt.close();
			} else {
				Statement stmt = DBManager.getConnection().createStatement();
				stmt.execute(query);
				stmt.close();
			}
		} catch (Exception e) {
			_editor.setText(e.getMessage());
		}
	}
}